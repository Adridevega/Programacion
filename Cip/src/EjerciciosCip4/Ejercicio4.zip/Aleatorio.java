package EjerciciosCip4;

public class Aleatorio {

	public static void main(String[] args) {
		  System.out.println(String.format("%.0f", Math.random()*11));
		
	}

}
